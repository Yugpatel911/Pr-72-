# TNK-M9-PRO-C72-PCP-BP

Class 72 PCP boilerplate code

To run the project follow the below commands:

```
* git clone https://github.com/Tynker-Computer-Vision/TNK-M9-PRO-C72-PCP-BP.git
* cd TNK-M9-PRO-C72-PCP-BP
* python3 -m venv myenv
* source myenv/bin/activate ( For Linux & Mac )
* myenv/Scripts/activate.bat ( Windows )
* pip install -r requirements.txt
* python3 main.py
```

---
